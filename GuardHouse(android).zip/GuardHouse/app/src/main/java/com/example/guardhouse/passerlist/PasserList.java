package com.example.guardhouse.passerlist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.guardhouse.InsertPasser;
import com.example.guardhouse.R;
import com.example.guardhouse.basefile.CarData;
import com.example.guardhouse.basefile.PasserData;
import com.example.guardhouse.basefile.seviceConnectActivity;
import com.example.guardhouse.carlist.CarList;

import org.json.JSONObject;

public class PasserList extends seviceConnectActivity {
    private PasserAdapter passerAdapter;
    private ListView passerListView;
    EditText editPasserName;
    int selectPasserId = 0;
    String selectPasserName;
    String selectPasserRank;
    String selectPasserDuty;
    String passerName;
    PasserListReciever passerListReciever;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passer_list);

        passerListReciever = new PasserListReciever();
        editPasserName = findViewById(R.id.edit_passer_list);

        serviceBind(PasserList.this, false);
        passerAdapter = new PasserAdapter();
        //passerAdapter.addItem(new PasserDTO(5,"김관장","2중대 중계조장","상사"));


        passerListView = findViewById(R.id.passer_list);
        passerListView.setAdapter(passerAdapter);

        passerListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                PasserDTO passerDTO = (PasserDTO)passerAdapter.getItem(position);
                Log.e("정보 확인", "passer id" + passerDTO.getPasserId() + ", passer name : "+ passerDTO.getPasserName() + ", passer duty :" + passerDTO.getPasserDuty());

                selectPasserId = passerDTO.getPasserId();
                selectPasserName = passerDTO.getPasserName();
                selectPasserRank = passerDTO.getPasserRank();
                selectPasserDuty = passerDTO.getPasserDuty();

                Toast.makeText(getApplicationContext(),"선택된 통행인 : "+ selectPasserName,Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(passerListReciever);
    }

    @Override
    protected void onResume() {
        super.onResume();

        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("DATA");
        registerReceiver(passerListReciever, theFilter);
    }

    public void passerListOnClick(View view){
        switch (view.getId()){
            case R.id.passer_list_add:
                addPasser();
                break;
            case R.id.passer_list_remove:
                removePasser();
                break;
            case R.id.passer_list_select:
                selectPasser();
                break;
            case  R.id.passer_list_search:
                searchPasser();
                break;
        }
    }
    public void addPasser(){
        Intent intent = new Intent(getApplicationContext(), InsertPasser.class);
        startActivity(intent);
    }
    public void removePasser(){
        JSONObject sendJson = new JSONObject();
        String deleteQuery = "DELETE FROM enter_record WHERE passer_id ="+selectPasserId +";";
        sendJson = makeJson.makeListRequest("insert_data", "passer", deleteQuery);
        myService.sendMessage(sendJson.toString());

        deleteQuery = "DELETE FROM passer WHERE passer_id ="+selectPasserId +";";
        sendJson = makeJson.makeListRequest("insert_data", "passer", deleteQuery);
        myService.sendMessage(sendJson.toString());
    }
    public void selectPasser(){
        Intent resultIntent = new Intent();
        resultIntent.putExtra("passer_id",selectPasserId);
        resultIntent.putExtra("passer_rank", selectPasserRank);
        resultIntent.putExtra("passer_name", selectPasserName);
        resultIntent.putExtra("passer_duty", selectPasserDuty);

        setResult(201, resultIntent);
        finish();
    }
    public void searchPasser(){
        passerName = "'%"+editPasserName.getText().toString()+"%'";

        JSONObject sendJson = new JSONObject();
        String selectQuery = "SELECT passer_id, passer_name, passer_duty, rank_name FROM passer NATURAL JOIN rank WHERE passer_name like"+passerName +" ORDER BY passer_id;";
        sendJson = makeJson.makeListRequest("list_request", "passer", selectQuery);

        myService.sendMessage(sendJson.toString());
    }

    public class PasserListReciever extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            passerAdapter = new PasserAdapter();
            for(PasserData pd : myService.passerDataArray){
                passerAdapter.addItem(new PasserDTO(pd.passerId, pd.passerName, pd.passerDuty, pd.passerRank));
                Log.e("랭크 확인", pd.passerRank);
            }
            passerListView.setAdapter(passerAdapter);
        }
    }


}
