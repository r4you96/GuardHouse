package com.example.guardhouse;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.guardhouse.basefile.seviceConnectActivity;

import org.json.JSONObject;

import java.sql.Array;

public class InsertPasser extends seviceConnectActivity {
    EditText editPasserName;
    EditText editPasserDuty;
    Spinner rankSpinner;
    int rankId = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_passer);

        serviceBind(InsertPasser.this, false);
        editPasserName = findViewById(R.id.insert_passer_name);
        editPasserDuty = findViewById(R.id.insert_passer_duty);

        rankSpinner = (Spinner)findViewById(R.id.insert_passer_rank_spinner);
        String[] rankStr = getResources().getStringArray(R.array.rankArray);
        Log.e("어댑터 확인", rankStr.toString());



        Log.e("스피너 확인", rankSpinner.toString());
        ArrayAdapter rankAdapter = ArrayAdapter.createFromResource(this, R.array.rankArray, android.R.layout.simple_spinner_item);
        rankAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        Log.e("어댑터 확인", rankAdapter.toString());

        rankSpinner.setAdapter(rankAdapter);
        rankSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("어댑터 확인", rankSpinner.getSelectedItemPosition()+"");
                rankId = rankSpinner.getSelectedItemPosition()+1;

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }


    public void onInsertPasser(View view){
        JSONObject query = new JSONObject();
        JSONObject sendJson = new JSONObject();
        String passerName = "'"+editPasserName.getText().toString()+"'";
        String passerDuty = "'" + editPasserDuty.getText().toString() +"'";

        String insertQuery = "INSERT INTO passer (passer_name, rank_id, passer_duty) Value ("+passerName+ "," + rankId + "," +passerDuty + ");";
        sendJson = makeJson.justMessage("insert_data", insertQuery);

        myService.sendMessage(sendJson.toString());
        finish();
    }

}
