package com.example.guardhouse.basefile;

public class PasserData {
    public int passerId;
    public String passerName, passerRank, passerDuty;
    public PasserData(int passerId, String passerName, String passerDuty, String passerRank){
        this.passerId = passerId;
        this.passerName = passerName;
        this.passerRank = passerRank;
        this.passerDuty = passerDuty;
    }
}
