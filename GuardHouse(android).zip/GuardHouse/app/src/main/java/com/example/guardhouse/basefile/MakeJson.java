package com.example.guardhouse.basefile;

import org.json.JSONException;
import org.json.JSONObject;

public class MakeJson {
    public JSONObject justMessage(String msg_type, String content){
        JSONObject data = new JSONObject();
        try {
            data.put("msg_type", msg_type);
            data.put("msg_content", content);
        }
        catch (JSONException e){
            e.printStackTrace();
        }

        return data;
    }
    public JSONObject makeMessage(String msg_type, JSONObject query){
        JSONObject data = new JSONObject();
        try {
            data.put("msg_type", msg_type);
            data.put("msg_content", query);
        }
        catch (JSONException e){
            e.printStackTrace();
        }

        return data;
    }
    public JSONObject makeListRequest(String msg_type, String list_type,String content){
        JSONObject data = new JSONObject();
        try {
            data.put("msg_type", msg_type);
            data.put("list_type", list_type);
            data.put("msg_content", content);
        }
        catch (JSONException e){
            e.printStackTrace();
        }

        return data;
    }
}
