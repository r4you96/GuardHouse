package com.example.guardhouse.basefile;

public class CarData{
    public int carId;
    public String carNumber, carDescription, carType;
    public CarData(int carId, String carNumber, String carDescription, String carType){
        this.carId = carId;
        this.carNumber = carNumber;
        this.carDescription = carDescription;
        this.carType = carType;
    }
}