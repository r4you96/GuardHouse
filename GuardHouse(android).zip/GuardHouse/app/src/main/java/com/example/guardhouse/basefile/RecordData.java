package com.example.guardhouse.basefile;

public class RecordData {
    public int recordId, enterType;
    public String carNumber, passerName, rankName, enterPurpose, recordTime;

    public RecordData(int recordId, int enterType,String carNumber, String passerName, String rankName, String enterPurpose, String recordTime){
        this.recordId = recordId;
        this.carNumber = carNumber;
        this.enterType = enterType;
        this.passerName = passerName;
        this.rankName = rankName;
        this.enterPurpose =enterPurpose;
        this.recordTime = recordTime;
    }
}
