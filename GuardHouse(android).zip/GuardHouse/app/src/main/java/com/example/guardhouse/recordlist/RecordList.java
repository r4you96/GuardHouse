package com.example.guardhouse.recordlist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.example.guardhouse.InsertPasser;
import com.example.guardhouse.InsertRecord;
import com.example.guardhouse.R;
import com.example.guardhouse.basefile.CarData;
import com.example.guardhouse.basefile.RecordData;
import com.example.guardhouse.basefile.seviceConnectActivity;
import com.example.guardhouse.passerlist.PasserList;

import org.json.JSONObject;

public class RecordList extends seviceConnectActivity {
    private RecordAdapter recordAdapter;
    private ListView recordListView;
    EditText editPasserName;
    int selectRecordId = 0;
    RecordListReciever recordListReciever;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_list);

        recordListReciever = new RecordListReciever();
        editPasserName = findViewById(R.id.edit_record_list);

        serviceBind(RecordList.this, false);
        recordAdapter = new RecordAdapter();
        //recordAdapter.addItem(new RecordDTO(5,1,"33육7820","정승민", "하사","그냥", "2019-09-09 12:34"));


        recordListView = findViewById(R.id.record_list);
        recordListView.setAdapter(recordAdapter);

        recordListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                RecordDTO recordDTO = (RecordDTO)recordAdapter.getItem(position);
                Log.e("정보 확인", "차 id" + recordDTO.getRecordId() + ", car number : "+ recordDTO.getCarNumber() + ", car description :" + recordDTO.getPasserName());
                selectRecordId = recordDTO.getRecordId();
            }
        });
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(recordListReciever);
    }

    @Override
    protected void onResume() {
        super.onResume();

        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("DATA");
        registerReceiver(recordListReciever, theFilter);
    }

    public void recordListOnClick(View view){
        switch (view.getId()){
            case R.id.record_list_add:
                addRecord();
                break;
            case R.id.record_list_remove:
                removeRecord();
                break;
            case  R.id.record_list_search:
                searchRecord();
                break;
        }
    }
    public void addRecord(){
        Intent intent = new Intent(getApplicationContext(), InsertRecord.class);
        startActivity(intent);
    }
    public void removeRecord(){
        JSONObject sendJson = new JSONObject();
        String deleteQuery = "DELETE FROM enter_record WHERE enter_record_id ="+selectRecordId +";";
        sendJson = makeJson.makeListRequest("insert_data", "record", deleteQuery);
        myService.sendMessage(sendJson.toString());

    }
    public void searchRecord(){

        String passerName = "'%"+editPasserName.getText().toString()+"%'";

        JSONObject sendJson = new JSONObject();
        String selectQuery = "SELECT enter_record_id, enter_type, car_number, passer_name, rank_name, enter_purpose, enter_time FROM " +
                "car NATURAL JOIN enter_record NATURAL JOIN passer NATURAL JOIN rank WHERE passer_name like "+passerName +" ORDER BY enter_record_id DESC;";
        sendJson = makeJson.makeListRequest("list_request", "record", selectQuery);

        myService.sendMessage(sendJson.toString());
    }
    public class RecordListReciever extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            recordAdapter = new RecordAdapter();
            for(RecordData rd : myService.recordDataArray){
                Log.e("additem enter_type", rd.enterType+"a");
                recordAdapter.addItem(new RecordDTO(rd.recordId, rd.enterType ,rd.carNumber, rd.passerName, rd.rankName, rd.enterPurpose, rd.recordTime));
            }
            recordListView.setAdapter(recordAdapter);
        }
    }


}
