package com.example.guardhouse.passerlist;

public class PasserDTO {
    private int resId;
    private int passerId;
    private String passerName;
    private String passerDuty;
    private String passerRank;

    public PasserDTO(int passerId, String passerName, String passerDuty, String passerRank){
        setPasserId(passerId);
        setPasserName(passerName);
        setPasserDuty(passerDuty);
        setPasserRank(passerRank);
    }

    public int getPasserId() {
        return passerId;
    }

    public void setPasserId(int passerId) {
        this.passerId = passerId;
    }

    public String getPasserName() {
        return passerName;
    }

    public void setPasserName(String passerName) {
        this.passerName = passerName;
    }

    public String getPasserDuty() {
        return passerDuty;
    }

    public void setPasserDuty(String passerDuty) {
        this.passerDuty = passerDuty;
    }

    public String getPasserRank() {
        return passerRank;
    }

    public void setPasserRank(String passerRank) {
        this.passerRank = passerRank;
    }
}
