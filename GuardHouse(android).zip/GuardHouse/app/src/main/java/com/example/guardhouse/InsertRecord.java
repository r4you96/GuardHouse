package com.example.guardhouse;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.guardhouse.basefile.seviceConnectActivity;
import com.example.guardhouse.carlist.CarList;
import com.example.guardhouse.passerlist.PasserList;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import androidx.annotation.Nullable;

public class InsertRecord extends seviceConnectActivity {
    TextView carIdTextView;
    TextView carNumberTextView;
    TextView carDescriptionTextView;
    TextView passerIdTextView;
    TextView passerRankTextView;
    TextView passerNameTextView;
    TextView passerDutyTextView;
    RadioButton outerRadioButton;
    EditText enterPurposeEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_record);

        outerRadioButton = findViewById(R.id.enter_type_radio1);
        enterPurposeEditText = findViewById(R.id.insert_record_enter_purpose_edit_text);

        carIdTextView = findViewById(R.id.insert_record_car_id);
        carNumberTextView =findViewById(R.id.insert_record_car_number);
        carDescriptionTextView = findViewById(R.id.insert_record_car_description);

        passerIdTextView = findViewById(R.id.insert_record_passer_id);
        passerNameTextView = findViewById(R.id.insert_record_passer_name);
        passerRankTextView = findViewById(R.id.insert_record_passer_rank);
        passerDutyTextView = findViewById(R.id.insert_record_passer_duty);

        serviceBind(InsertRecord.this, false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == 101){
            Log.e("차량 검색 완료", "통행 차량 번호" + data.getExtras().getString("car_number"));
            Toast.makeText(getApplicationContext(),"통행 차량 번호" + data.getExtras().getString("car_number"), Toast.LENGTH_LONG).show();
            carIdTextView.setText(data.getExtras().getInt("car_id") + "");
            carNumberTextView.setText(data.getExtras().getString("car_number"));
            carDescriptionTextView.setText(data.getExtras().getString("car_description"));
        }
        else if(resultCode == 201){
            Log.e("통행인 완료", "통행 인" );
            Toast.makeText(getApplicationContext(),"통행인 이름" + data.getExtras().getString("passer_name"), Toast.LENGTH_LONG).show();
            passerIdTextView.setText(data.getExtras().getInt("passer_id")+"");
            passerNameTextView.setText(data.getExtras().getString("passer_name"));
            passerRankTextView.setText(data.getExtras().getString("passer_rank"));
            passerDutyTextView.setText(data.getExtras().getString("passer_duty"));
        }
    }

    public void onInsertRecord(View view){
        switch (view.getId()){
            case R.id.insert_record_car_search :
                carSearch();
                break;
            case R.id.insert_record_passer_search:
                passerSearch();
                break;
            case R.id.insert_record_button:
                insertRecord();
                break;
        }
    }
    public void carSearch(){
        Intent carListIntent = new Intent(getApplicationContext(), CarList.class);
        startActivityForResult(carListIntent,1001);
    }
    public void passerSearch(){
        Intent passerListIntent = new Intent(getApplicationContext(), PasserList.class);
        startActivityForResult(passerListIntent,2001);
    }
    public void insertRecord(){
        JSONObject query = new JSONObject();
        JSONObject sendJson = new JSONObject();

        int enterType;
        if(outerRadioButton.isChecked())
            enterType = 0;
        else
            enterType = 1;
        int carId = Integer.parseInt(carIdTextView.getText().toString());
        int passerId = Integer.parseInt(passerIdTextView.getText().toString());
        String enterPurpose = "'" + enterPurposeEditText.getText().toString() + "'";

        String nowDate = "'"+getNowDate()+"'";

        if(carId != 0 && passerId != 0){
            String insertQuery = "INSERT INTO enter_record (enter_type, car_id, passer_id, enter_purpose, enter_time) Value ("+enterType+"," + carId + "," +passerId +","+enterPurpose+","+ nowDate+");";
            sendJson = makeJson.justMessage("insert_data", insertQuery);

            myService.sendMessage(sendJson.toString());
        }

        finish();
    }
    public String getNowDate(){
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String formatDate = sdfNow.format(date);

        return formatDate;
    }
}
