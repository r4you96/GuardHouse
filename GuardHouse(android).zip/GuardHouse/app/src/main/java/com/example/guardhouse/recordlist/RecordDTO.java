package com.example.guardhouse.recordlist;

public class RecordDTO {
    private int resId;
    private int recordId, enterType;
    private String carNumber, passerName, rank, enterPurpose, recordTime;

    public RecordDTO(int recordId,int enterType, String carNumber, String passerName, String rankName, String enterPurpose, String recordTime){
        setRecordId(recordId);
        setCarNumber(carNumber);
        setPasserName(passerName);
        setRank(rankName);
        setEnterPurpose(enterPurpose);
        setRecordTime(recordTime);
        setEnterType(enterType);
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }
    public void setEnterType(int enterType) {
        this.enterType = enterType;
    }
    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public String getPasserName() {
        return passerName;
    }

    public void setPasserName(String passerName) {
        this.passerName = passerName;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getRecordTime() {
        return recordTime;
    }

    public String getEnterPurpose() {
        return enterPurpose;
    }

    public void setEnterPurpose(String enterPurpose) {
        this.enterPurpose = enterPurpose;
    }

    public void setRecordTime(String recordTime) {
        this.recordTime = recordTime;
    }
    public int getEnterType() {
        return enterType;
    }
}
