package com.example.guardhouse.carlist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.guardhouse.R;

import java.util.ArrayList;

public class CarAdapter extends BaseAdapter {
    private ArrayList<CarDTO> listCustom = new ArrayList<>();

    // ListView에 보여질 Item 수
    @Override
    public int getCount() {
        return listCustom.size();
    }

    // 하나의 Item(ImageView 1, TextView 2)
    @Override
    public Object getItem(int position) {
        return listCustom.get(position);
    }

    // Item의 id : Item을 구별하기 위한 것으로 position 사용
    @Override
    public long getItemId(int position) {
        return position;
    }

    // 실제로 Item이 보여지는 부분
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        CustomViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_car, null, false);

            holder = new CustomViewHolder();
            holder.imageView = (ImageView) convertView.findViewById(R.id.car_image);
            holder.carNumber = (TextView) convertView.findViewById(R.id.item_car_number);
            holder.carDescription = (TextView) convertView.findViewById(R.id.item_car_description);
            holder.carType = convertView.findViewById(R.id.ridemode);

            convertView.setTag(holder);
        } else {
            holder = (CustomViewHolder) convertView.getTag();
        }

        CarDTO dto = listCustom.get(position);
        if(dto.getCarType().equals("군대 소유 차량"))
            holder.imageView.setImageResource(R.drawable.jeep);
        else if(dto.getCarType().equals("민간인 차량"))
            holder.imageView.setImageResource(R.drawable.car);
        else if(dto.getCarType().equals("군인 소유 사제 차량"))
            holder.imageView.setImageResource(R.drawable.soldier_car);
        holder.carNumber.setText(dto.getCarNumber());
        holder.carDescription.setText(dto.getCarDescription());
        holder.carType.setText(dto.getCarType());

        return convertView;
    }

    class CustomViewHolder {
        ImageView imageView;
        TextView carNumber;
        TextView carDescription;
        TextView carType;
    }

    // MainActivity에서 Adapter에있는 ArrayList에 data를 추가시켜주는 함수
    public void addItem(CarDTO dto) {
        listCustom.add(dto);
    }
}
