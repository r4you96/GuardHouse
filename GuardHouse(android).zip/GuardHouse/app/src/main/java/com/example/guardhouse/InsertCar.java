package com.example.guardhouse;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.example.guardhouse.basefile.MyService;
import com.example.guardhouse.basefile.MakeJson;
import com.example.guardhouse.basefile.seviceConnectActivity;

import org.json.JSONObject;

public class InsertCar extends seviceConnectActivity {
    EditText editCarDescription;
    EditText editCarNumber;
    int carType = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_car);

        serviceBind(InsertCar.this, false);
        editCarNumber = findViewById(R.id.insert_car_number);
        editCarDescription = findViewById(R.id.insert_car_description);
    }


    public void onInsertCar(View view){
        JSONObject query = new JSONObject();
        JSONObject sendJson = new JSONObject();
        String carNumber = "'"+editCarNumber.getText().toString()+"'";
        String carDescription = "'" + editCarDescription.getText().toString() +"'";

        String insertQuery = "INSERT INTO car (car_type_id, car_number, car_description) Value ("+carType+ "," + carNumber + "," +carDescription + ");";
        sendJson = makeJson.justMessage("insert_data", insertQuery);

        myService.sendMessage(sendJson.toString());

        finish();
    }
    public void carTypeButtonClick(View view){
        switch (view.getId()){
            case R.id.car_type_radio1:
                carType = 1;
                break;
            case R.id.car_type_radio2:
                carType = 2;
                break;
            case R.id.car_type_radio3:
                carType = 3;
                break;
        }
        Toast.makeText(getApplicationContext(), "선택된 타입은 "+carType, Toast.LENGTH_LONG).show();
    }

}
