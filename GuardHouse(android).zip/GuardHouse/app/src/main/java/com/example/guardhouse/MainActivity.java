package com.example.guardhouse;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.guardhouse.basefile.RecordData;
import com.example.guardhouse.basefile.seviceConnectActivity;
import com.example.guardhouse.carlist.CarList;
import com.example.guardhouse.passerlist.PasserList;
import com.example.guardhouse.recordlist.RecordAdapter;
import com.example.guardhouse.recordlist.RecordDTO;
import com.example.guardhouse.recordlist.RecordList;

import org.json.JSONObject;

public class MainActivity extends seviceConnectActivity {
    MainActivityReciever mainActivityReciever;
    EditText editsend;
    TextView temperatureTextView;
    TextView cdsTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainActivityReciever = new MainActivityReciever();

        serviceBind(MainActivity.this, true);

        temperatureTextView = findViewById(R.id.main_temprature_text_view);
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mainActivityReciever);
    }

    @Override
    protected void onResume() {
        super.onResume();

        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("GPIO");
        registerReceiver(mainActivityReciever, theFilter);
    }

    public void goActivity(View view){
        Intent intent;
        switch (view.getId()){
            case R.id.go_insert_car_activity:
                intent = new Intent(getApplicationContext(), CarList.class);
                startActivity(intent);
                break;
            case R.id.go_insert_passer_activity:
                intent = new Intent(getApplicationContext(), PasserList.class);
                startActivity(intent);
                break;
            case R.id.go_insert_record_activity:
                intent = new Intent(getApplicationContext(), InsertRecord.class);
                startActivity(intent);
                break;
            case R.id.go_record_list_activity:
                intent = new Intent(getApplicationContext(), RecordList.class);
                startActivity(intent);
                break;
        }
    }
    public void openDoor(View view){
        JSONObject query = new JSONObject();
        JSONObject sendJson = new JSONObject();
        sendJson = makeJson.justMessage("gpio", "open_door");

        myService.sendMessage(sendJson.toString());
    }
    public class MainActivityReciever extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            temperatureTextView.setText(myService.temperature+"");
            //cdsTextView.setText("현재 조도값은 : "+myService.cdsValue +"입니다.");
        }
    }

}
