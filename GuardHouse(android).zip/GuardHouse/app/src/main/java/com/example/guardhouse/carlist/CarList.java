package com.example.guardhouse.carlist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.guardhouse.InsertCar;
import com.example.guardhouse.R;
import com.example.guardhouse.basefile.CarData;
import com.example.guardhouse.basefile.seviceConnectActivity;

import org.json.JSONObject;

public class CarList extends seviceConnectActivity {
    private CarAdapter carAdapter;
    private ListView carListView;
    EditText editCarNumber;
    int selectCarId = 0;
    String selectCarNumber = null;
    String selectCarDescription = null;
    String carNumber;
    CarListReciever carListReciever;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_list);

        carListReciever = new CarListReciever();
        editCarNumber = findViewById(R.id.edit_car_list);

        serviceBind(CarList.this, false);
        carAdapter = new CarAdapter();
        //carAdapter.addItem(new CarDTO(5,"33육3399","코란도 스포츠","군용차량"));


        carListView = findViewById(R.id.car_list);
        carListView.setAdapter(carAdapter);

        carListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                CarDTO carDTO = (CarDTO)carAdapter.getItem(position);
                Log.e("정보 확인", "차 id" + carDTO.getCarId() + ", car number : "+ carDTO.getCarNumber() + ", car description :" + carDTO.getCarDescription());
                selectCarId = carDTO.getCarId();
                selectCarNumber = carDTO.getCarNumber();
                selectCarDescription = carDTO.getCarDescription();
                Toast.makeText(getApplicationContext(),"선택 차량 : "+carDTO.getCarNumber(),Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(carListReciever);
    }

    @Override
    protected void onResume() {
        super.onResume();

        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("DATA");
        registerReceiver(carListReciever, theFilter);
    }

    public void carListOnClick(View view){
        switch (view.getId()){
            case R.id.car_list_add:
                addCar();
                break;
            case R.id.car_list_remove:
                removeCar();
                break;
            case R.id.car_list_select:
                selectCar();
                break;
            case  R.id.car_list_search:
                searchCar();
                break;
        }
    }
    public void addCar(){
        Intent intent = new Intent(getApplicationContext(), InsertCar.class);
        startActivity(intent);
    }
    public void removeCar(){
        JSONObject sendJson = new JSONObject();
        String deleteQuery = "DELETE FROM enter_record WHERE car_id ="+selectCarId +";";
        sendJson = makeJson.makeListRequest("insert_data", "car", deleteQuery);
        myService.sendMessage(sendJson.toString());

        deleteQuery = "DELETE FROM car WHERE car_id ="+selectCarId +";";
        sendJson = makeJson.makeListRequest("insert_data", "car", deleteQuery);
        myService.sendMessage(sendJson.toString());
    }
    public void selectCar(){
        Intent resultIntent = new Intent();
        resultIntent.putExtra("car_id",selectCarId);
        resultIntent.putExtra("car_number", selectCarNumber);
        resultIntent.putExtra("car_description", selectCarDescription);

        setResult(101, resultIntent);
        finish();
    }
    public void searchCar(){
        carNumber = "'%"+editCarNumber.getText().toString()+"%'";

        JSONObject sendJson = new JSONObject();
        String selectQuery = "SELECT car_id, car_number, car_type_name, car_description FROM car NATURAL JOIN car_type WHERE car_number like"+carNumber +" ORDER BY car_id;";
        sendJson = makeJson.makeListRequest("list_request", "car", selectQuery);

        myService.sendMessage(sendJson.toString());
    }
    public class CarListReciever extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            carAdapter = new CarAdapter();
            for(CarData cd : myService.carDataArray){
                carAdapter.addItem(new CarDTO(cd.carId, cd.carNumber, cd.carDescription, cd.carType));
            }
            carListView.setAdapter(carAdapter);
            new Thread(){
                public void run(){

                }
            }.start();
        }
    }


}
