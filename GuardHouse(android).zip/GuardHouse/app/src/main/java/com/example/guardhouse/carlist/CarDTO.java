package com.example.guardhouse.carlist;

public class CarDTO {
    private int resId;
    private int carId;
    private String carNumber;
    private String carDescription;
    private String carType;

    public CarDTO(int carId, String carNumber, String carDescription, String carType){
        setCarId(carId);
        setCarDescription(carDescription);
        setCarNumber(carNumber);
        setCarType(carType);
    }

    public int getResId() {
        return resId;
    }
    public void setResId(int resId) {
        this.resId = resId;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public String getCarDescription() {
        return carDescription;
    }

    public void setCarDescription(String carDescription) {
        this.carDescription = carDescription;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }
}
